# Vérification du moteur JEAN FRANK

Depuis ce dossier, exécuter `npm test` avec Node.js 20 ou plus récent.
Les tests vérifient les conversions de cases 1–50, la position initiale, les coups simples,
la prise obligatoire et majoritaire, les prises des pions dans les deux sens, les dames volantes,
la promotion, le refus d'un coup illégal, la fin de partie, la notation et la répétition.

Ces tests valident le moteur local uniquement. Ils ne valident pas encore Firebase, les comptes,
les abonnements, le professeur IA, les cours ou la synchronisation réseau.
