import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,createPosition,legalMoves,apply,rc,sq,notation,isDrawClaimable} from '../rules.js';

test('numérotation FMJD 1–50 et conversion aller-retour',()=>{
  for(let n=1;n<=50;n++){const [r,c]=rc(n);assert.equal(sq(r,c),n);}
  assert.equal(sq(-1,1),null); assert.throws(()=>rc(0));
});
test('position initiale: 40 pièces, 9 coups blancs légaux',()=>{
  const s=initial(); assert.equal(Object.keys(s.board).length,40); assert.equal(legalMoves(s).length,9);
  assert.ok(legalMoves(s).every(m=>m.captured.length===0));
});
test('un coup simple change le trait et déplace la pièce',()=>{
  const s=initial(),m=legalMoves(s)[0],n=apply(s,m);
  assert.equal(n.turn,'b'); assert.equal(n.board[m.to],'w'); assert.equal(n.board[m.from],undefined);
});
test('prise obligatoire et choix de la prise majoritaire',()=>{
  const s=createPosition({whiteMen:[32],blackMen:[27,18,10],turn:'w'});
  const ms=legalMoves(s); assert.ok(ms.length>0); assert.ok(ms.every(m=>m.captured.length===Math.max(...ms.map(x=>x.captured.length))));
});
test('un pion capture en avant et en arrière',()=>{
  const forward=createPosition({whiteMen:[32],blackMen:[27],turn:'w'});
  assert.ok(legalMoves(forward).some(m=>m.captured.includes(27)));
  const backward=createPosition({whiteMen:[32],blackMen:[37],turn:'w'});
  assert.ok(legalMoves(backward).some(m=>m.captured.includes(37)));
});
test('une dame volante peut atterrir sur plusieurs cases après la prise',()=>{
  const s=createPosition({whiteKings:[46],blackMen:[28],turn:'w'});
  const ms=legalMoves(s); assert.ok(ms.some(m=>m.captured.includes(28))); assert.ok(new Set(ms.map(m=>m.to)).size>1);
});
test('promotion à dame à la fin du coup',()=>{
  const s=createPosition({whiteMen:[6],turn:'w'});
  const m=legalMoves(s).find(x=>x.to<=5); assert.ok(m); const n=apply(s,m); assert.equal(n.board[m.to],'wk');
});
test('un coup illégal est refusé',()=>{const s=initial();assert.throws(()=>apply(s,{from:31,to:20,path:[31,20],captured:[]}));});
test('la partie se termine si le joueur suivant ne possède plus de coup',()=>{
  const s=createPosition({whiteMen:[11],turn:'w'});
  const m=legalMoves(s)[0]; const n=apply(s,m); assert.equal(n.result,'Blanc gagne'); assert.deepEqual(legalMoves(n),[]);
});
test('la notation de prise utilise x',()=>assert.equal(notation({path:[32,21,12],captured:[27,17]}),'32x21x12'));
test('une position répétée trois fois devient réclamable',()=>{
  const s=createPosition({whiteKings:[46],blackKings:[5],turn:'w'});
  const sig='w|5:bk,46:wk'; s.positionKeys[sig]=3; assert.equal(isDrawClaimable(s),true);
});
